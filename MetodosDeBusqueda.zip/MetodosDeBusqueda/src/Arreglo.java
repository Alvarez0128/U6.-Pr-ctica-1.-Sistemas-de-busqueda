
/**
 * 
 * @author C3S4R_4LV
 */
public class Arreglo {
    public int[] generarArreglo(int tam){
        int[] arreglo=new int[tam];
        for(int i=0;i<arreglo.length;i++){
            do{
                arreglo[i]=(int) (Math.random() * (100)+1);
            }while(arreglo[i]==0);
        }
        return arreglo;
    }
    
    public String BusquedaSecuencial(String s, int valor){
        int x=valor;
        int pos,cont=0;
        String cad="";
        if(s.isEmpty()){
            return " no existe";
        }
        String[] vector=s.split(", ");
        
        for(int i=0;i<vector.length;i++){
            for(int j=i;j<vector.length;j++){
                if(vector[i]==vector[j]){
                    if(Integer.parseInt(vector[i])==x){
                        cad+="posicion: "+(j+1)+", ";
                        cont++;
                        return "El valor "+x+" fue encontrado en la posición: "+cad;
                    }    
                }
            }    
        }
        
        return "El valor "+x+" no existe";
    }
    
    public String BusquedaBinaria(String s, int valor){
        
        int x=valor,pos;
        if(s.isEmpty()){
            return " no existe";
        }
        String[] arre=s.split(", ");
        String temp;
         
        int inf=0,sup=arre.length-1,centro;
        while(inf<=sup){
            centro=(sup+inf)/2;
            if(Integer.parseInt(arre[centro])==x){
                pos=centro+1;
                return "El valor "+x+" fue encontrado en la posición: "+pos;
            }else if(x<(Integer.parseInt(arre[centro]))){
                sup=centro-1;
            }else{
                inf=centro+1;
            }
        }
        return "El valor "+x+" no existe";
    }
    
    public String ordenar(String s){
        String arre[] = s.split(", ");
        String temp;
        
        for(int i=1;i<arre.length;i++){
            for(int j=0; j<arre.length-i;j++){
                if(Integer.parseInt(arre[j])>Integer.parseInt(arre[j+1])){
                    temp=arre[j];
                    arre[j]=arre[j+1];
                    arre[j+1]=temp;
                }
            }
        }      
        String cad="";
        for(int i=0;i<arre.length;i++){
            cad+=arre[i]+", ";
        }
        return cad;
    }
}
